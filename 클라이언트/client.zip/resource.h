﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// client.rc에서 사용되고 있습니다.
//
#define IDC_MYICON                      2
#define IDD_CLIENT_DIALOG               102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_CLIENT                      107
#define IDI_SMALL                       108
#define IDC_CLIENT                      109
#define IDR_MAINFRAME                   128
#define IDB_PNG1                        129
#define IDB_PNG2                        130
#define IDB_PNG3                        131
#define IDB_PNG4                        132
#define IDB_PNG5                        133
#define IDB_PNG6                        134
#define IDB_PNG7                        135
#define IDB_PNG8                        136
#define IDB_PNG9                        137
#define IDB_PNG10                       138
#define IDB_PNG11                       139
#define IDB_PNG12                       140
#define IDB_PNG13                       141
#define IDB_PNG14                       142
#define IDB_PNG15                       143
#define IDB_PNG16                       144
#define IDB_PNG17                       145
#define IDB_PNG18                       146
#define IDB_PNG19                       147
#define IDB_PNG20                       148
#define IDB_PNG21                       149
#define IDB_PNG22                       150
#define IDB_PNG23                       151
#define IDB_PNG24                       152
#define IDB_PNG25                       153
#define IDB_PNG26                       154
#define IDB_PNG27                       155
#define IDB_PNG28                       156
#define IDB_PNG29                       157
#define IDB_PNG30                       158
#define IDB_PNG31                       159
#define IDB_PNG32                       160
#define IDB_PNG33                       161
#define IDB_PNG34                       162
#define IDB_PNG35                       163
#define IDB_PNG36                       164
#define IDB_PNG37                       165
#define IDB_PNG38                       166
#define IDB_PNG39                       167
#define IDB_PNG40                       168
#define IDB_PNG41                       169
#define IDB_PNG42                       170
#define IDB_PNG43                       171
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        172
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
